/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpcs_425;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class CPCS_425 {

    public static void main(String[] args) throws IOException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Input File");

        JFileChooser outputChooser = new JFileChooser();
        outputChooser.setDialogTitle("Save File");
        outputChooser.setDialogType(JFileChooser.SAVE_DIALOG); // تعيين نوع النافذة لحفظ الملف

        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        while (choice != 3) {
            System.out.println("------------------------------------------------------------");
            System.out.println("                 Encrypted Files Application                ");
            System.out.println("------------------------------------------------------------");
            System.out.println("1. Encrypt Files");
            System.out.println("2. Decrypt Files");
            System.out.println("3. Exit");
            System.out.print("Please select your choice: ");

            choice = scanner.nextInt();

            if (choice == 1) {
               // System.out.println("You selected Encrypt Files.");
                int inputResult = fileChooser.showOpenDialog(null);
                if (inputResult == JFileChooser.APPROVE_OPTION) {
                    File inputFile = fileChooser.getSelectedFile();
                    BufferedReader input = new BufferedReader(new FileReader(inputFile));

                    int outputResult = outputChooser.showSaveDialog(null);
                    if (outputResult == JFileChooser.APPROVE_OPTION) {
                        File outputFile = outputChooser.getSelectedFile();
                        String userInputFileName = outputFile.getName();

                        PrintWriter output = new PrintWriter(outputFile);

                        cipher.encrypte(input, output, userInputFileName);

                        input.close();
                        output.close();
                    }
                }
            } else if (choice == 2) {
                //System.out.println("You selected Decrypt Files.");
                int inputResult = fileChooser.showOpenDialog(null);
                if (inputResult == JFileChooser.APPROVE_OPTION) {
                    File inputFile = fileChooser.getSelectedFile();
                    BufferedReader input = new BufferedReader(new FileReader(inputFile));

                    int outputResult = outputChooser.showSaveDialog(null);
                    if (outputResult == JFileChooser.APPROVE_OPTION) {
                        File outputFile = outputChooser.getSelectedFile();
                        String userInputFileName = outputFile.getName();

                        PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter(outputFile)));

                        cipher.decrypt(input, output, userInputFileName);

                        input.close();
                        output.close();
                    }
                }
            } else if (choice == 3) {
                System.out.println("Exiting...");
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
