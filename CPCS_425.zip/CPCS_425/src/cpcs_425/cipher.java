/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpcs_425;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author alzhr
 */
public class cipher {
    
    public static void encrypte(BufferedReader input,PrintWriter output, String fileName) throws IOException{
    String read=input.readLine();
    
    while(read != null){
      // Step 1: Remove leading and trailing whitespace
            read = read.trim();

      // Step 2: Convert to uppercase
            read = read.toUpperCase();
            
      // Step 3: Move first half to the last half
            int length = read.length();
            //System.out.println(length);
            int halfLength = length / 2;
            //System.out.println( halfLength);
            //this for odd
            String fHalf = read.substring(0, halfLength + (length % 2));
            //System.out.println(fHalf);
            String lHalf = read.substring(halfLength + (length % 2), length);
            //System.out.println(lHalf);
            read = lHalf + fHalf;
            // Step 4: Swap first 2 characters with last 2 characters 
            //System.out.println(read);
            char[] chars = read.toCharArray();
            char temp = chars[0]; 
            chars[0] = chars[length - 2]; 
            chars[length - 2] = temp;
            temp = chars[1];
            chars[1] = chars[length - 1]; 
            chars[length - 1] = temp;
            // back to string
            read = new String(chars); 
            
            // Step 5: Swap two characters left of the middle with two characters that follow
            //System.out.println(read);
            
            int middleIndex = length / 2;
            //System.out.println(middleIndex);
            char[] swappedChars = read.toCharArray();
            temp = swappedChars[middleIndex - 2];
            //System.out.println(temp);
            swappedChars[middleIndex - 2] = swappedChars[middleIndex];
            swappedChars[middleIndex] = temp;
            temp = swappedChars[middleIndex - 1];
            swappedChars[middleIndex - 1] = swappedChars[middleIndex + 1];
            swappedChars[middleIndex + 1] = temp;
            //back to string
            read = new String(swappedChars);
            // Step 6: Perform character substitutions
            read= read
                    .replace("A", "@")
                    .replace("E", "=")
                    .replace("I", "!")
                    .replace("J", "?")
                    .replace("O", "*")
                    .replace("P", "#")
                    .replace("R", "&")
                    .replace("S", "$")
                    .replace("T", "+")
                    .replace("V", "^")
                    .replace("X", "%")
                    .replace(" ", "_");
            
            
            
            
            //System.out.println(read);
       //print 
        output.println(read);
       //read next line
    read=input.readLine();
    System.out.println("The file was encrypted");
    }
    input.close();
    output.close();
    
    File newOutputFile = new File(fileName);
    
    File cipherFile = new File(output.toString());
    if (cipherFile.renameTo(newOutputFile)) {
        System.out.println("File saved as: " + fileName);
    } else {
       // System.out.println("Error renaming the file!");
    }
    }
    
 public static void decrypt(BufferedReader input, PrintWriter output, String fileName) throws IOException {
    String read = input.readLine();

    while (read != null) {
        // Step 1: Reverse character substitutions
        read = read
                .replace("@", "A")
                .replace("=", "E")
                .replace("!", "I")
                .replace("?", "J")
                .replace("*", "O")
                .replace("#", "P")
                .replace("&", "R")
                .replace("$", "S")
                .replace("+", "T")
                .replace("^", "V")
                .replace("%", "X")
                .replace("_", " ");

        // Step 2: Remove leading and trailing whitespace
        read = read.trim();

        // Step 3: Reverse swapping of two characters left of the middle with two characters that follow
        int length = read.length();
        int middleIndex = length / 2;
        char[] chars = read.toCharArray();
        char temp = chars[middleIndex - 2];
        chars[middleIndex - 2] = chars[middleIndex];
        chars[middleIndex] = temp;
        temp = chars[middleIndex - 1];
        chars[middleIndex - 1] = chars[middleIndex + 1];
        chars[middleIndex + 1] = temp;
        read = new String(chars);

        // Step 4: Reverse swapping of first 2 characters with last 2 characters
        temp = chars[0];
        chars[0] = chars[length - 2];
        chars[length - 2] = temp;
        temp = chars[1];
        chars[1] = chars[length - 1];
        chars[length - 1] = temp;
        read = new String(chars);

        // Step 5: Reverse moving first half to the last half
        String lHalf = read.substring(0, middleIndex);
        String fHalf = read.substring(middleIndex, length);
        if (length % 2 == 1) {
            fHalf = fHalf.substring(0, fHalf.length() - 1);
        }
        read = fHalf + lHalf;

        // Step 6: Convert to lowercase
        read = read.toLowerCase();

        //System.out.println(read);
        output.println(read);

        // Read next line
        read = input.readLine();
        System.out.println("The file was decrypted");
        
    }

    input.close();
    output.close();
    File newOutputFile = new File(fileName);
    File decryptFile = new File(output.toString());
    if (decryptFile.renameTo(newOutputFile)) {
        System.out.println("File saved as: " + fileName);
    } else {
        //System.out.println("Error renaming the file!");
    }
}}